# himu29

After cloning the repo <code>cd</code> into the project and hit <code>npm install</code>

Run <code>webpack-dev-server</code>

This should create a server and it will be hosted on <code>http://localhost:8080</code>

Dependencies: <code>Node webpack-dev-server installed globally</code>
