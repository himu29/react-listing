const config = {
	API_URL: 'https://api.themoviedb.org/3/',
	API_KEY: '5bb9b7db52d27c45225fb601546dcefc',
	POPULAR_MOVIES: 'https://api.themoviedb.org/3/movie/popular?api_key=5bb9b7db52d27c45225fb601546dcefc&language=en-US&page=1',
	CONFIG: 'https://api.themoviedb.org/3/configuration?api_key=5bb9b7db52d27c45225fb601546dcefc'
}

export default config